

#include "TablaSimbolos.h"

//Funcion que inicializa el analizador lexico
void inicializarAnalizadorLexico(char *nombreFichero);
//Funcion que invoca el analizador sintáctico para obtener un componente léxico
CompLexico siguiente_componente_lexico();

//Funcion para acabar el analizador lexico
void finalizarAnalizadorLexico();


