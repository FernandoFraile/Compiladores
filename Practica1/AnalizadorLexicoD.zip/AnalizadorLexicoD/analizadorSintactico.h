

//Funcion que va a innvocar a siguiente_componente_lexico y va a imprimir el resultado
void analizadorSintactico();