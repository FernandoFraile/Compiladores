//Palabras reservadas
#define IMPORT 300 //import
#define DOUBLE 301 //double
#define INT 302 //int
#define WHILE 303 //while
#define FOREACH 304 //foreach
#define RETURN 305 //return
#define VOID 306 //void
#define CAST 307 //cast
//Fin de palabras reservadas
#define INTEGER 308 
#define ID 309 
#define STRING 310 
#define FLOATING 311
#define ENDFILE 312 
#define IGUALIGUAL 313 
#define MASIGUAL 314 
#define MASMAS 315 

