Intrucciones de compilacion y ejecucion: 

Es necesario tener todos los archivos en el mismo directorio (main, cabeceras, codigo fuente y regression.d). Para compilarlo se proporciona un Makefile, 
por lo que solo es necesario ejecutar el comando 'make'. Cuando esté compilado, ejecutar con el comando './ejecutable regression.d'. Si se desea 
ejecutar con otro archivo de entrada, ejeutar como './ejecutable <nombre_archivo>'

Qué se va a mostra al ejecutarse: 

Primero se mostrará la tabla de símbolos después de iniciarse. Posteriormente, se mostrará el resultado del análisis léxico, mostrando el par lexema y 
componente léxico de la forma <Componente_léxico,Lexema>. Finalmente se vuelve a imprimir la tabla de símbolos para ver como ha quedado. 

